package com.cg.project.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PaymentDetailsBean {
	@FindBy(how=How.NAME,name="txtFN")
	private WebElement txtFN ;

	@FindBy(how=How.NAME,name="debit")
	private WebElement debit;

	@FindBy(how=How.NAME,name="cvv")
	private WebElement cvv;

	@FindBy(how=How.NAME,name="month")
	private WebElement month;

	@FindBy(how=How.NAME,name="year")
	private WebElement year;
	
	@FindBy(how=How.ID,using="btnPayment")
	private WebElement paymentSubmitBtn;

	public String getTxtFN() {
		return txtFN.getAttribute("value");
	}

	public void setTxtFN(String txtFN) {
		this.txtFN.sendKeys(txtFN);
	}

	public String getDebit() {
		return debit.getAttribute("value");
	}

	public void setDebit(String debit) {
		this.debit.sendKeys(debit);
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public String getMonth() {
		return month.getAttribute("value");
	}

	public void setMonth(String month) {
		this.month.sendKeys(month);
	}

	public String getYear() {
		return year.getAttribute("value");
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}
	
	public void clickSignUp() {
		paymentSubmitBtn.click();
	}
}
