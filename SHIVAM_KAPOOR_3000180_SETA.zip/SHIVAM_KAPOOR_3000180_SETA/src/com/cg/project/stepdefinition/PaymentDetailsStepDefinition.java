package com.cg.project.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.PaymentDetailsBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDetailsStepDefinition {

	private WebDriver driver;

	private PaymentDetailsBean pageBean;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\software backup\\chromedriver.exe" );
		driver=new ChromeDriver();	
	}

	@Given("^User is accessing PaymentPage on Borwser$")
	public void user_is_accessing_PaymentPage_on_Borwser() throws Throwable {
		driver.get("D:\\3000180_Shivam_Kapoor\\BDDCucumberSelenium\\Set B\\PaymentDetails.html");
		pageBean = PageFactory.initElements(driver, PaymentDetailsBean.class);
	}

	@When("^user is trying to submit data without entering 'Card Holder Name'$")
	public void user_is_trying_to_submit_data_without_entering_Card_Holder_Name() throws Throwable {
		pageBean.clickSignUp();
	}

	@Then("^'Please fill the Card holder name' alert message should display$")
	public void please_fill_the_Card_holder_name_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the Card holder name";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request without entering 'Debit Card Number '$")
	public void user_is_trying_to_submit_request_without_entering_Debit_Card_Number() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setTxtFN("Shivam");
		pageBean.clickSignUp();

	}

	@Then("^'Please fill the Debit card Number' alert message should display$")
	public void please_fill_the_Debit_card_Number_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the Debit card Number";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request without entering 'CVV'$")
	public void user_is_trying_to_submit_request_without_entering_CVV() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setDebit("78451212458745");
		pageBean.clickSignUp();
	}

	@Then("^'Please fill the CVV' alert message should display$")
	public void please_fill_the_CVV_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the CVV";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request without entering valid 'Expiration month'$")
	public void user_is_trying_to_submit_request_without_entering_valid_Expiration_month() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setCvv("454");
		pageBean.clickSignUp();
	}

	@Then("^'Please fill expiration month' alert message should display$")
	public void please_fill_expiration_month_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill expiration month";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request without selecting  valid 'Expiration Year'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_Expiration_Year() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setMonth("02");
		pageBean.clickSignUp();
	}

	@Then("^'Please fill the expiration year' alert message should display$")
	public void please_fill_the_expiration_year_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please fill the expiration year";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to do payment after entering valid 'set of information'$")
	public void user_is_trying_to_do_payment_after_entering_valid_set_of_information() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setTxtFN("Shivam");
		pageBean.setDebit("784512458745");
		pageBean.setCvv("454");
		pageBean.setMonth("02");
		pageBean.setYear("1997");
		pageBean.clickSignUp();
	}

	@Then("^'Conference Room Booking successfully done!!!' alert message should display$")
	public void conference_Room_Booking_successfully_done_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Conference Room Booking successfully done!!!";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}
}
