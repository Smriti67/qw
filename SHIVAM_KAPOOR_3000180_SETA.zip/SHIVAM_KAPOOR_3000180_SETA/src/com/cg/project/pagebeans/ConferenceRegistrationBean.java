package com.cg.project.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationBean {

	@FindBy(how=How.NAME,name="txtFN")
	private WebElement txtFN ;

	@FindBy(how=How.NAME,name="txtLN")
	private WebElement txtLN;

	@FindBy(how=How.NAME,name="Email")
	private WebElement Email;

	@FindBy(how=How.NAME,name="Phone")
	private WebElement Phone;

	@FindBy(how=How.NAME,name="size")
	private WebElement size;

	@FindBy(how=How.NAME,name="Address")
	private WebElement Address;

	@FindBy(how=How.NAME,name="Address2")
	private WebElement Address2;

	@FindBy(how=How.NAME,name="city")
	private WebElement city;

	@FindBy(how=How.NAME,name="state")
	private WebElement state;

	@FindBy(how=How.NAME,name="memberStatus")
	private WebElement memberStatus;

	public String getTxtFN() {
		return txtFN.getAttribute("value");
	}

	public void setTxtFN(String txtFN) {
		this.txtFN.sendKeys(txtFN);
	}

	public String getTxtLN() {
		return txtLN.getAttribute("value");
	}

	public void setTxtLN(String txtLN) {
		this.txtLN.sendKeys(txtLN);
	}

	public String getEmail() {
		return Email.getAttribute("value");
	}

	public void setEmail(String Email) {
		this.Email.clear();
		this.Email.sendKeys(Email);
	}

	public String getPhone() {
		return Phone.getAttribute("value");
	}

	public void setPhone(String Phone) {
		this.Phone.clear();
		this.Phone.sendKeys(Phone);
	}

	public String getSize() {
		return new Select(this.size).getFirstSelectedOption().getText();
	}

	public void setSize(String size) {
		Select select=new Select(this.size);
		select.selectByVisibleText(size);
	}

	public String getAddress() {
		return Address.getAttribute("value");
	}

	public void setAddress(String Address) {
		this.Address.clear();
		this.Address.sendKeys(Address);
	}

	public String getAddress2() {
		return Address2.getAttribute("value");
	}

	public void setAddress2(String Address2) {
		this.Address2.clear();
		this.Address2.sendKeys(Address2);
	}

	public String getCity() {
		return city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getState() {
		return state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public String getMemberStatus() {
		return memberStatus.getAttribute("value");
	}

	public void setMemberStatus(String memberStatus) {
		this.memberStatus.sendKeys(memberStatus);
	}
}